package com.sourcey.materiallogindemo;

/**
 * Created by pisitchai on 8/3/2018 AD.
 */

public class LoginData {
    public static String name;
    public static String address;
    public static String email;
    public static String mobile;
    public static String password;
    public static String reEnterPassword;
}
